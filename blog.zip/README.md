<!-- docs/home.md -->
* [Home](/)
* [Flask](docs/flask.md)
* [Redis](docs/redis.md)
* [JUC](docs/juc.md)
* [JVM](docs/jvm.md)
* [七周七语言](docs/七周七语言.md)
* [k8s私有化部署](docs/k8s私有化部署.md)
* [好用工具](docs/tools.md)
* [架构](docs/架构.md)
* [分布式ID生成方案](docs/分布式ID生成方案.md)
* [zookeeper](docs/zookeeper.md)
* [收藏文章](docs/收藏文章.md)
* [书签](docs/书签.html)
---


# 开发实践
---



# 站点
---

本项目基于 [Docsify](https://docsify.js.org/#/) 进行构建，并使用开源小工具 Gitee Pages Actions 实现站点的自动部署更新。
